package doctorapp;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField userField = new JTextField(18);
    private final JPasswordField passField = new JPasswordField(18);

    public LoginFrame() {
        setTitle("Doctor Appointment System - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 340);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Doctor Appointment Booking", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setOpaque(true);
        title.setBackground(new Color(0, 121, 107));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(18, 10, 18, 10));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0; c.gridy = 0; form.add(new JLabel("Username:"), c);
        c.gridx = 1; form.add(userField, c);
        c.gridx = 0; c.gridy = 1; form.add(new JLabel("Password:"), c);
        c.gridx = 1; form.add(passField, c);

        JButton loginBtn = new JButton("Login");
        JButton regBtn = new JButton("Register");
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        btns.add(loginBtn); btns.add(regBtn);
        c.gridx = 0; c.gridy = 2; c.gridwidth = 2; c.anchor = GridBagConstraints.CENTER;
        form.add(btns, c);

        JLabel hint = new JLabel("Demo login: demo / demo123");
        hint.setForeground(Color.GRAY);
        c.gridy = 3; form.add(hint, c);

        root.add(form, BorderLayout.CENTER);
        setContentPane(root);
        getRootPane().setDefaultButton(loginBtn);

        loginBtn.addActionListener(e -> doLogin());
        regBtn.addActionListener(e -> doRegister());
    }

    private void doLogin() {
        String u = userField.getText().trim();
        String p = new String(passField.getPassword());
        if (u.isEmpty() || p.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username aur password dono bhariye.");
            return;
        }
        String name = DataStore.login(u, p);
        if (name == null) {
            JOptionPane.showMessageDialog(this, "Galat username ya password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }
        new DashboardFrame(u, name).setVisible(true);
        dispose();
    }

    private void doRegister() {
        JTextField name = new JTextField(15), user = new JTextField(15);
        JPasswordField pass = new JPasswordField(15);
        JPanel p = new JPanel(new GridLayout(0, 2, 6, 6));
        p.add(new JLabel("Full Name:")); p.add(name);
        p.add(new JLabel("Username:")); p.add(user);
        p.add(new JLabel("Password:")); p.add(pass);
        int r = JOptionPane.showConfirmDialog(this, p, "Register", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;
        String pw = new String(pass.getPassword());
        if (name.getText().trim().isEmpty() || user.getText().trim().isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Saari fields bharna zaruri hai.");
            return;
        }
        if (DataStore.register(user.getText(), pw, name.getText()))
            JOptionPane.showMessageDialog(this, "Registration ho gaya! Ab login kijiye.");
        else
            JOptionPane.showMessageDialog(this, "Ye username pehle se hai.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
