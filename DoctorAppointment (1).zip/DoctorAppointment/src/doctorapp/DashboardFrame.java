package doctorapp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DashboardFrame extends JFrame {
    private final String username;
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Doctor", "Date", "Time", "Reason"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);

    public DashboardFrame(String username, String fullName) {
        this.username = username;
        setTitle("Doctor Appointment System - " + fullName);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(760, 480);
        setLocationRelativeTo(null);

        JLabel welcome = new JLabel("  Welcome, " + fullName);
        welcome.setFont(new Font("SansSerif", Font.BOLD, 16));
        welcome.setForeground(Color.WHITE);
        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> { new LoginFrame().setVisible(true); dispose(); });
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(new Color(0, 121, 107));
        top.setBorder(BorderFactory.createEmptyBorder(10, 6, 10, 10));
        top.add(welcome, BorderLayout.WEST);
        top.add(logout, BorderLayout.EAST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Book Appointment", buildBookPanel());
        tabs.addTab("My Appointments", buildListPanel());
        tabs.addChangeListener(e -> loadAppointments());

        add(top, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
        loadAppointments();
    }

    private JPanel buildBookPanel() {
        JComboBox<String> doctor = new JComboBox<>(DataStore.DOCTORS);
        List<String> dates = new ArrayList<>();
        for (int i = 0; i < 14; i++) dates.add(LocalDate.now().plusDays(i).toString());
        JComboBox<String> date = new JComboBox<>(dates.toArray(new String[0]));
        JComboBox<String> time = new JComboBox<>(DataStore.SLOTS);
        JTextField reason = new JTextField(22);
        JButton book = new JButton("Book Appointment");

        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.anchor = GridBagConstraints.WEST;
        String[] labels = {"Doctor:", "Date:", "Time Slot:", "Reason:"};
        JComponent[] fields = {doctor, date, time, reason};
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0; c.gridy = i; p.add(new JLabel(labels[i]), c);
            c.gridx = 1; p.add(fields[i], c);
        }
        c.gridx = 0; c.gridy = 4; c.gridwidth = 2; c.anchor = GridBagConstraints.CENTER;
        p.add(book, c);

        book.addActionListener(e -> {
            if (reason.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Reason likhiye.");
                return;
            }
            String err = DataStore.book(username, (String) doctor.getSelectedItem(),
                    (String) date.getSelectedItem(), (String) time.getSelectedItem(), reason.getText());
            if (err != null) {
                JOptionPane.showMessageDialog(this, err, "Slot Unavailable", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Appointment book ho gayi!");
                reason.setText("");
                loadAppointments();
            }
        });
        return p;
    }

    private JPanel buildListPanel() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        table.setRowHeight(24);
        table.removeColumn(table.getColumnModel().getColumn(0)); // hide ID
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        JButton cancel = new JButton("Cancel Selected Appointment");
        cancel.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Pehle koi appointment select kijiye."); return; }
            int ok = JOptionPane.showConfirmDialog(this, "Cancel karni hai?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                DataStore.cancel((String) model.getValueAt(table.convertRowIndexToModel(row), 0));
                loadAppointments();
            }
        });
        p.add(cancel, BorderLayout.SOUTH);
        return p;
    }

    private void loadAppointments() {
        model.setRowCount(0);
        for (String[] f : DataStore.appointmentsFor(username))
            model.addRow(new Object[]{f[0], f[2], f[3], f[4], f[5]});
    }
}
