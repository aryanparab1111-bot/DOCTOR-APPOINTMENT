package doctorapp;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Simple file based storage (no database needed). Files are created in the "data" folder. */
public class DataStore {
    static final Path DIR = Paths.get("data");
    static final Path USERS = DIR.resolve("users.txt");        // username|password|fullname
    static final Path APPTS = DIR.resolve("appointments.txt"); // id|username|doctor|date|time|reason

    public static final String[] DOCTORS = {
        "Dr. Sharma - Cardiologist", "Dr. Mehta - Dermatologist", "Dr. Patil - Pediatrician",
        "Dr. Khan - Orthopedic", "Dr. Iyer - General Physician", "Dr. Desai - ENT Specialist"
    };
    public static final String[] SLOTS = {
        "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM",
        "04:00 PM", "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM"
    };

    static {
        try {
            Files.createDirectories(DIR);
            if (!Files.exists(USERS)) Files.write(USERS, Arrays.asList("demo|demo123|Demo Patient"));
            if (!Files.exists(APPTS)) Files.createFile(APPTS);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private static List<String> read(Path p) {
        try { return new ArrayList<>(Files.readAllLines(p)); }
        catch (IOException e) { return new ArrayList<>(); }
    }
    private static void write(Path p, List<String> lines) {
        try { Files.write(p, lines); } catch (IOException e) { e.printStackTrace(); }
    }
    private static String clean(String s) { return s.replace("|", " ").trim(); }

    /** Returns full name if login ok, else null. */
    public static String login(String user, String pass) {
        for (String l : read(USERS)) {
            String[] f = l.split("\\|", -1);
            if (f.length >= 3 && f[0].equals(user) && f[1].equals(pass)) return f[2];
        }
        return null;
    }

    public static boolean register(String user, String pass, String name) {
        user = clean(user); pass = clean(pass); name = clean(name);
        List<String> list = read(USERS);
        for (String l : list) if (l.split("\\|", -1)[0].equalsIgnoreCase(user)) return false;
        list.add(user + "|" + pass + "|" + name);
        write(USERS, list);
        return true;
    }

    /** Returns null if booked, else error message. */
    public static String book(String user, String doctor, String date, String time, String reason) {
        List<String> list = read(APPTS);
        for (String l : list) {
            String[] f = l.split("\\|", -1);
            if (f.length >= 5 && f[2].equals(doctor) && f[3].equals(date) && f[4].equals(time))
                return "Ye slot already booked hai. Koi aur time chuniye.";
        }
        list.add(System.currentTimeMillis() + "|" + user + "|" + doctor + "|" + date + "|" + time + "|" + clean(reason));
        write(APPTS, list);
        return null;
    }

    public static List<String[]> appointmentsFor(String user) {
        List<String[]> out = new ArrayList<>();
        for (String l : read(APPTS)) {
            String[] f = l.split("\\|", -1);
            if (f.length >= 6 && f[1].equals(user)) out.add(f);
        }
        return out;
    }

    public static void cancel(String id) {
        List<String> list = read(APPTS);
        list.removeIf(l -> l.startsWith(id + "|"));
        write(APPTS, list);
    }
}
